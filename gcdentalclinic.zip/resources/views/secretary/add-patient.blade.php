@section('title', 'Add Patient')
<x-admin-layout>
    <div>
        <livewire:secretary.add-patient/>
    </div>
</x-admin-layout>
