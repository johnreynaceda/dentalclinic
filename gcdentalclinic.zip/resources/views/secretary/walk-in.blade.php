@section('title', 'Walk-In Appointment')
<x-admin-layout>
    <div>
        <livewire:secretary.walk-in/>
    </div>
</x-admin-layout>
