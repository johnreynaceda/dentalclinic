@section('title', 'History')
<x-admin-layout>
    <div>
        <livewire:secretary.history />
    </div>
</x-admin-layout>
