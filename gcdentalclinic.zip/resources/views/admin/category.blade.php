@section('title', 'Category')
<x-admin-layout>
    <div>
        <livewire:admin.category-list />
    </div>
</x-admin-layout>
