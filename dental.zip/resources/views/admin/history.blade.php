@section('title', "history")
<x-admin-layout>
    <div>
        <livewire:admin.history />
    </div>
</x-admin-layout>
