@section('title', "Doctor's Schedule")
<x-admin-layout>
    <div>
        <livewire:admin.doctor-list />
    </div>
</x-admin-layout>
