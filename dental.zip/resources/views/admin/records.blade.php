@section('title', 'Records')
<x-admin-layout>
    <div>
        <livewire:secretary.records />
    </div>
</x-admin-layout>
