<x-patient-layout>
    <div>
        <livewire:patient.appointment />
    </div>
</x-patient-layout>
